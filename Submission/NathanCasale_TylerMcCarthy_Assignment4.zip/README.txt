NOTE:

We have included the sgraph directory with the project. Replace the headers/sgraph directory with this one in order to run our program.

Other than that, compiling the program and running it should be straightforward. A more indepth explanation of the program's use and features
can be found in the documentation.